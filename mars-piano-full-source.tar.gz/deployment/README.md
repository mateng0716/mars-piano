# piano.gotomars.me 上线记录

目标：复用腾讯北京 `82.157.156.144` 上现有 GoToMars Caddy 入口，新增独立静态目录与 `piano.gotomars.me` 路由。DNS 应新增 `piano` A 记录指向该 IP。不要覆盖现有 Caddyfile；应先读取服务器当前配置，合并新站点块后执行 `caddy validate` 并 reload。

本项目无数据库和服务端密钥。待线上权限可用后：

1. 确认服务器现有 Caddy 配置、静态站目录约定及剩余容量。
2. 传输 Git 版本对应的 `index.html`、`style.css`、`app.js`、`course-data.js`、`assets/` 到独立发布目录，原子切换版本链接。
3. 在当前 Caddyfile 合并 `piano.gotomars.me` 站点，`root` 指向独立发布目录，使用 `file_server`，验证配置后 reload。
4. 在现有 DNS 管理处添加 A 记录，验证权威解析、可信 HTTPS、首页和音频/采样 MIME、iPad 麦克风权限。
5. 记录 Git commit、服务器发布目录、Caddy 配置哈希和回退版本。别用旧的 Caddy 模板覆盖英语站、签程、统计路由。

当前状态以本地任务日志及服务器实时回执为准。
